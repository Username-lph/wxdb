// pages/message/message.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        msgList : [
            {
                id: '1',
                title: '标题一',
                date: '2019-3-1',
                image: 'https://m.360buyimg.com/mobilecms/s750x366_jfs/t1/7681/10/11784/116684/5c2ed31bE80014381/827d8eb5ce229bb7.jpg!cr_1125x549_0_72!q70.jpg.dpg',
                desc: '越努力越幸运'
            },
            {
                id: '2',
                title: '标题二',
                date: '2019-3-3',
                image: 'https://m.360buyimg.com/mobilecms/s750x366_jfs/t1/9028/36/11613/148654/5c2ca094E6467ff6a/1fc8764cf84d9989.jpg!cr_1125x549_0_72!q70.jpg.dpg',
                desc: '越努力越幸运'
            },
            {
                id: '3',
                title: '标题三',
                date: '2019-3-6',
                image: 'https://m.360buyimg.com/mobilecms/s750x366_jfs/t1/18134/22/4175/76321/5c2eb78cEb4d08e38/57e70078565399fa.jpg!cr_1125x549_0_72!q70.jpg.dpg',
                desc: '越努力越幸运'
            },
            {
                id: '4',
                title: '标题四',
                date: '2019-3-8',
                image: 'https://m.360buyimg.com/mobilecms/s750x366_jfs/t1/11919/6/5101/346584/5c2f18a5E4b479f8a/13957f99ed1a0b14.jpg!cr_1125x549_0_72!q70.jpg.dpg',
                desc: '越努力越幸运'
            },
            {
                id: '5',
                title: '标题五',
                date: '2019-3-10',
                image: 'https://m.360buyimg.com/mobilecms/jfs/t1/24056/17/2005/80908/5c186655E14dc7cf2/820a7029a2540e25.jpg!q70.jpg.dpg',
                desc: '越努力越幸运'
            }
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})